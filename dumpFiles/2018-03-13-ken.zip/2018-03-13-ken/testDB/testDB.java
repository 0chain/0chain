import org.bouncycastle.jcajce.provider.digest.SHA3.DigestSHA3;
import org.bouncycastle.jcajce.provider.digest.SHA3.Digest256;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.Timestamp;
import java.sql.SQLException;
import java.sql.ResultSet;

import javax.sql.DataSource;
import java.util.Calendar;
import java.nio.ByteBuffer;

public class testDB
{
	public static void main(String args[])
	{
		String name = "some name";
		int age = 13;
		byte[] hash = null;
		Timestamp stamp;
		int i, n = 100000;
		try{
			String url = "jdbc:postgresql://172.33.1.7:5432/0chain";
			Connection conn = DriverManager.getConnection(url, "postgres", "2YwP4sOz8I");
			System.out.println("After getConnection");
			long start = System.nanoTime();
			Statement stmt = null;
			stmt = conn.createStatement();
			for(i = 0; i < n; i++)
			{
				Calendar c = Calendar.getInstance();
				stamp = new Timestamp(c.getTime().getTime());
				DigestSHA3 sha3 = new Digest256();
				sha3.update(name.getBytes());
				sha3.update(ByteBuffer.allocate(4).putInt(age).array());
				sha3.update(stamp.toString().getBytes());
				hash = sha3.digest();
				
				try{
					String query = "INSERT into transaction VALUES ('"+name+"','"+age+"','"+stamp+"','"+hash+"');";
	                
	                int oid = stmt.executeUpdate(query);
	                if(oid != 1)
	                {
	                	System.out.println("bad database... bad");
	                }    
	                //stmt.close(); 
				}catch(Exception e)
				{
					e.printStackTrace();
				}

			}
			if(conn != null & !conn.isClosed())
			{
				conn.close();
			}
			long finishe = System.nanoTime();
			System.out.println((finishe-start)/1000000000.0);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
}