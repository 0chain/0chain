import java.io.IOException;
import java.io.PrintWriter;
 
import javax.servlet.ServletConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Timestamp;
import java.util.Calendar;

public class simple_server extends HttpServlet{
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException
	{
		PrintWriter writer = response.getWriter();
		Calendar c = Calendar.getInstance();
		writer.println(new Timestamp(c.getTime().getTime()).toString());
		writer.flush();
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException
	{
		PrintWriter writer = response.getWriter();
		Calendar c = Calendar.getInstance();
		writer.println(new Timestamp(c.getTime().getTime()).toString());
		writer.flush();
	}

}