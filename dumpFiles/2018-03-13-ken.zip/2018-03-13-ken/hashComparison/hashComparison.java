
import java.nio.ByteBuffer;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Security;
import java.security.Signature;
import java.security.SignatureException;
import java.util.Random;
import org.bouncycastle.jcajce.provider.digest.SHA3.DigestSHA3;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.jcajce.provider.digest.SHA3.Digest256;
import java.util.Calendar;
import java.sql.Timestamp;

public class hashComparison {
	public static void main(String args[])
	{
		int i;
		int n = 1000000;
	
		int dataLength = 128;
		PublicKey pub = null;
		PrivateKey pri = null;
		Security.addProvider(new BouncyCastleProvider());
		try {
			KeyPairGenerator keyGen = KeyPairGenerator.getInstance("EC");
			KeyPair keypair = keyGen.generateKeyPair();
			pub = keypair.getPublic();
			pri = keypair.getPrivate();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		long l = 0;
		transaction[] t = new transaction[n];
		hashComparison hc = new hashComparison();
		for(i = 0; i < n; i++)
		{
		
			t[i] = hc.new transaction(dataLength);
			t[i].setData(createRandomBytes(dataLength));
			t[i].setKey(pub);
		}

		long start = System.nanoTime();
		for(i = 0; i < n; i++)
		{
			DigestSHA3 sha3_256 = new Digest256();
			sha3_256.update(t[i].getPublicKey().getEncoded());
			sha3_256.update(t[i].getData());
			t[i].setHash(sha3_256.digest());
		}
		long finished = System.nanoTime();
		System.out.println("Time to hash "+n+" transactions: "+(finished - start)/1000000000.0);
		
		start = System.nanoTime();
		for(i = 0; i < n ; i++)
		{
			Signature ecdsa = getECDSA();
			try {
				ecdsa.initSign(pri);
				ecdsa.update(t[i].getHash());
				t[i].setSign(ecdsa.sign());
			} catch (InvalidKeyException | SignatureException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		finished = System.nanoTime();
		System.out.println("Time to sign "+n+" transactions: "+(finished - start)/1000000000.0);
		
		boolean everythingIsFine = true;
		start = System.nanoTime();
		for(i = 0; i < n && everythingIsFine; i++)
		{
			Signature ecdsa = getECDSA();
			try {
				ecdsa.initVerify(pub);
				ecdsa.update(t[i].getHash());
				everythingIsFine = ecdsa.verify(t[i].getSign());
			} catch (InvalidKeyException | SignatureException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				everythingIsFine = false;
			}
		}
		if(!everythingIsFine)
		{
			System.out.println("you fucked up the code");
		}
		finished = System.nanoTime();
		System.out.println("Time to verify "+n+" signatures: "+(finished - start)/1000000000.0);
	}
	
	public static Signature getECDSA()
	{
		Signature ecdsa = null;
		try {
			ecdsa = Signature.getInstance("SHA3-256WITHECDSA", "BC");
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchProviderException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ecdsa;
	}
	
	public static byte[] createRandomBytes(int numberOfBytes)
	{
		byte[] b = new byte[numberOfBytes];
		new Random().nextBytes(b);
		return b;
	}
	
	class transaction
	{
		byte[] data;
		byte[] hash;
		byte[] signature;
		PublicKey publicKey;
		public transaction(int dataSize)
		{
			data = new byte[dataSize];
			hash = null;
			signature = null;
			publicKey = null;
		}
		
		public void setData(byte[] data)
		{
			this.data = data;
		}
		
		public void setSign(byte[] signature)
		{
			this.signature = signature;
		}
		
		public void setKey(PublicKey publicKey)
		{
			this.publicKey = publicKey;
		}
		
		public void setHash(byte[] hash)
		{
			this.hash = hash;
		}
		
		public byte[] getData()
		{
			return data;
		}
		
		public byte[] getSign()
		{
			return signature;
		}
		
		public PublicKey getPublicKey()
		{
			return publicKey;
		}
		
		public byte[] getHash()
		{
			return hash;
		}
	}
}
