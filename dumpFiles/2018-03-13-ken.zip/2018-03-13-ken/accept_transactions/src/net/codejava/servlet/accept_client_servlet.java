package net.codejava.servlet;
 
import java.io.IOException;
import java.io.PrintWriter;
 
import javax.servlet.ServletConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.Timestamp;
import java.sql.SQLException;
import java.sql.ResultSet;

import java.io.StringWriter;
import java.io.PrintWriter;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.bouncycastle.jcajce.provider.digest.SHA3.DigestSHA3;
import org.bouncycastle.jcajce.provider.digest.SHA3.Digest256;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import javax.xml.bind.DatatypeConverter;


public class accept_client_servlet extends HttpServlet {

    /**
     * this life-cycle method is invoked when this servlet is first accessed
     * by the client
     */
    public void init(ServletConfig config) {
        System.out.println("Servlet is being initialized");
    }
 
    /**
     * handles HTTP GET request
     */
    public void doGet(HttpServletRequest request, HttpServletResponse response)
	throws IOException {
 
        PrintWriter writer = response.getWriter();
        writer.println("<html>Hello!!!, I am a Java jdbc post servlet!<br/>");
		Connection conn = null;
 
        try {
	    Context initialContext = new InitialContext();
	    Context environmentContext = (Context) initialContext.lookup("java:comp/env");
	    DataSource dataSource = (DataSource) environmentContext.lookup("jdbc/postgres");
	    conn = dataSource.getConnection();
        if (conn != null) {
            writer.println("Connected to database<br/>");
			Statement stmt = null;
			try {
			    stmt = conn.createStatement();
			    ResultSet rs = stmt.executeQuery( "SELECT * FROM allowed_clients;" );
			    writer.println("<table border='1'>");
			    writer.println("<tr>");
			    writer.println("<th> HASH </th>");
			    writer.println("<th> KEY </th>");
			    writer.println("</tr>");
			    while ( rs.next() ) {
				String publicKey = rs.getString("public_key");
				String hash = rs.getString("hash_key");
				writer.println("<tr>");
				writer.println( "<th>" + publicKey +"</th>" );
				writer.println( "<th>" + hash + "</th>");
				writer.println("</tr>");
			    }
			    writer.println("</table>");
			    rs.close();		
			    stmt.close();	       
			} catch ( Exception e ) {
			    writer.println(e.getClass().getName()+": "+ e.getMessage() ); 
			    writer.println("<br/>");
			}	   	    		
            }
	} catch ( NamingException ne) {
	    writer.println(ne.getClass().getName()+": "+ ne.getMessage() ); 
	    writer.println("<br/>");
        } catch (SQLException ex) {
	    StringWriter sw = new StringWriter();
	    PrintWriter pw = new PrintWriter(sw);
	    ex.printStackTrace(pw);
	    String sStackTrace = sw.toString(); // stack trace as a string
	    writer.println(sStackTrace);
	    writer.println("<br/>");
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
	writer.println("Operation done successfully<br/>");
	writer.println("</html>");
        writer.flush();
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response)
    throws IOException {
    	PrintWriter writer = response.getWriter();
    	writer.println("<html>Hello!!!, I am a Java jdbc post servlet!<br/>");
    	String public_key = request.getParameter("public_key");
        String hash = request.getParameter("hash_key");
        Connection conn = null;

        try{
            Context initialContext = new InitialContext();
            Context environmentContext = (Context) initialContext.lookup("java:comp/env");
            DataSource dataSource = (DataSource) environmentContext.lookup("jdbc/postgres");
            conn = dataSource.getConnection();
            if(conn != null && verifyHash(public_key, hash) && !alreadyClient(hash))
            {
                writer.println("Connected to database<br/>");
                Statement stmt = null;
                try{
                    String query = "INSERT into allowed_clients VALUES ('"+hash+"','"+public_key+"');";
                    stmt = conn.createStatement();
                    int oid = stmt. executeUpdate(query);
                    writer.println("OID = " + oid+"<br/>");    
                    stmt.close();          
                } catch ( Exception e ) {
                    writer.println(e.getClass().getName()+": "+ e.getMessage() ); 
                    writer.println("<br/>");
                }
            }
            else if(verifyHash(public_key, hash) && alreadyClient(hash))
            {
            	writer.println("You're already a member");
            }
            else if(!verifyHash(public_key, hash))
            {
            	writer.println("You're key is hashed wrong");
            }
        } catch ( NamingException ne) {
        writer.println(ne.getClass().getName()+": "+ ne.getMessage() ); 
        writer.println("<br/>");
        } catch (SQLException ex) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        ex.printStackTrace(pw);
        String sStackTrace = sw.toString(); // stack trace as a string
        writer.println(sStackTrace);
        writer.println("<br/>");
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        writer.println("Operation done successfully<br/>");
        writer.println("</html>");
        writer.flush();

    }

    public static boolean alreadyClient(String hash)
    {
    	boolean isClient = false;
    	Connection conn = null;

        try{
            Context initialContext = new InitialContext();
            Context environmentContext = (Context) initialContext.lookup("java:comp/env");
            DataSource dataSource = (DataSource) environmentContext.lookup("jdbc/postgres");
            conn = dataSource.getConnection();
            if(conn != null)
            {
                Statement stmt = null;
                try{
                    String query = "select * from allowed_clients where hash = '"+hash+"';";
                    stmt = conn.createStatement();
                    ResultSet rs = stmt.executeQuery(query);  
                    if(rs.getFetchSize() > 0)
                    {
                    	isClient = true;
                    }  
                    stmt.close();          
                } catch ( Exception e ) {

                }
            }
        } catch ( NamingException ne) {
        
        } catch (SQLException ex) {
        
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {

            }
        }
        return isClient;
    }

    public static boolean verifyHash(String public_key, String hash)
    {
    	DigestSHA3 sha3 = new Digest256();
    	sha3.update(DatatypeConverter.parseBase64Binary(public_key));
    	return hashToString(sha3.digest()).equals(hash);
    }

    public static String hashToString(byte[] hash)
    {
    	StringBuffer buff = new StringBuffer();
    	for(byte b: hash)
    	{
    		buff.append(String.format("%02", b & 0xFF));
    	}
    	return buff.toString();
    }

}