package net.codejava.servlet;
 
import java.io.IOException;
import java.io.PrintWriter;
 
import javax.servlet.ServletConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.Timestamp;
import java.sql.SQLException;
import java.sql.ResultSet;

import java.io.StringWriter;
import java.io.PrintWriter;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;



public class transaction_jdbc_servlet extends HttpServlet {

    /**
     * this life-cycle method is invoked when this servlet is first accessed
     * by the client
     */
    public void init(ServletConfig config) {
        System.out.println("Servlet is being initialized");
    }
 
    /**
     * handles HTTP GET request
     */
    public void doGet(HttpServletRequest request, HttpServletResponse response)
	throws IOException {
 
        PrintWriter writer = response.getWriter();
        writer.println("<html>Hello!!!, I am a Java jdbc post servlet!<br/>");
		Connection conn = null;
 
        try {
	    Context initialContext = new InitialContext();
	    Context environmentContext = (Context) initialContext.lookup("java:comp/env");
	    DataSource dataSource = (DataSource) environmentContext.lookup("jdbc/postgres");
	    conn = dataSource.getConnection();
        if (conn != null) {
            writer.println("Connected to database<br/>");
			Statement stmt = null;
			try {
			    stmt = conn.createStatement();
			    ResultSet rs = stmt.executeQuery( "SELECT * FROM transaction;" );
			    writer.println("<table border='1'>");
			    writer.println("<tr>");
			    writer.println("<th> NAME </th>");
			    writer.println("<th> AGE </th>");
			    writer.println("<th> TIMESTAMP </th>");
			    writer.println("<th> HASH </th>");
			    writer.println("</tr>");
			    while ( rs.next() ) {
				String name = rs.getString("name");
				int age  = rs.getInt("age");
				Timestamp timestamp = rs.getTimestamp("timestamp");
				String hash = rs.getString("hash");
				writer.println("<tr>");
				writer.println( "<th>" + name +"</th>" );
				writer.println( "<th>" + age +"</th>");
				writer.println( "<th>" + timestamp.toString() + "</th>" );
				writer.println( "<th>" + hash + "</th>");
				writer.println("</tr>");
			    }
			    writer.println("</table>");
			    rs.close();		
			    stmt.close();	       
			} catch ( Exception e ) {
			    writer.println(e.getClass().getName()+": "+ e.getMessage() ); 
			    writer.println("<br/>");
			}	   	    		
            }
	} catch ( NamingException ne) {
	    writer.println(ne.getClass().getName()+": "+ ne.getMessage() ); 
	    writer.println("<br/>");
        } catch (SQLException ex) {
	    StringWriter sw = new StringWriter();
	    PrintWriter pw = new PrintWriter(sw);
	    ex.printStackTrace(pw);
	    String sStackTrace = sw.toString(); // stack trace as a string
	    writer.println(sStackTrace);
	    writer.println("<br/>");
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
	writer.println("Operation done successfully<br/>");
	writer.println("</html>");
        writer.flush();
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response)
    throws IOException {
    	PrintWriter writer = response.getWriter();
    	writer.println("<html>Hello!!!, I am a Java jdbc post servlet!<br/>");
    	String name = request.getParameter("name");
    	int age = Integer.parseInt(request.getParameter("age"));
        String timestamp = request.getParameter("timestamp");
        String hash = request.getParameter("t_hash_msg");
        Connection conn = null;

        try{
            Context initialContext = new InitialContext();
            Context environmentContext = (Context) initialContext.lookup("java:comp/env");
            DataSource dataSource = (DataSource) environmentContext.lookup("jdbc/postgres");
            conn = dataSource.getConnection();
            if(conn != null)
            {
                writer.println("Connected to database<br/>");
                Statement stmt = null;
                try{
                    String query = "INSERT into transaction VALUES ('"+name+"','"+age+"','"+timestamp+"','"+hash+"');";
                    stmt = conn.createStatement();
                    int oid = stmt. executeUpdate(query);
                    writer.println("OID = " + oid+"<br/>");    
                    stmt.close();          
                } catch ( Exception e ) {
                    writer.println(e.getClass().getName()+": "+ e.getMessage() ); 
                    writer.println("<br/>");
                }
            }
        } catch ( NamingException ne) {
        writer.println(ne.getClass().getName()+": "+ ne.getMessage() ); 
        writer.println("<br/>");
        } catch (SQLException ex) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        ex.printStackTrace(pw);
        String sStackTrace = sw.toString(); // stack trace as a string
        writer.println(sStackTrace);
        writer.println("<br/>");
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        writer.println("Operation done successfully<br/>");
        writer.println("</html>");
        writer.flush();

    }

    public static boolean verifyTransactionHash(String name, int age, Timestamp timestamp, String hash)
    {
    	return false;
    }
}