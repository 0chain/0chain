package com.zerochain.Transaction;

import java.io.Serializable;
import java.sql.Date;
import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
@Table(name = "transaction")
public class TransactionEntity implements Serializable{

	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private int id;
	
	@Column(name = "client_id")
	private String client_id;
	
	@Column(name = "data")
	private String data;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "timestamp", nullable = false)
	private Calendar timestamp;
	
	@Column(name = "hash_msg")
	private String hash_msg;
	
	@Column(name = "sign")
	private String sign;
	
	public TransactionEntity (String client_id,String data, Calendar timestamp,String hash_msg, String sign) {
		this.client_id = client_id;
		this.data = data;
		this.timestamp = timestamp;
		this.hash_msg = hash_msg;
		this.sign = sign;
	}
	
	public TransactionEntity() {
	}
	
	public int getId() {
		return id;
	}
	
	public void setId(int id){
		this.id = id;
	} 
	
	public String getClient_id() {
		return client_id;
	}
	public void setClient_id(String client_id) {
		this.client_id = client_id;
	}
	
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	
	public Calendar getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(Calendar timestamp) {
		this.timestamp = timestamp;
	}
	
	public String getHash_msg(String hash_msg) {
		return hash_msg;
	}
	
	public void setHash_msg(String hash_msg) {
		this.hash_msg = hash_msg;
	}
	
	public String getSign(String sign) {
		return sign;
	}
	public void setSign(String sign) {
		this.sign = sign;
	}

}
