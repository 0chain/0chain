package com.zerochain.Transaction;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zerochain.TransactionDAO.ITransactionDAO;

@Service("transactionService")
public class TransactionServiceImpl implements ITransactionService{
	@Autowired 
	private ITransactionDAO iTransactionDAO;
	
	@Override
	public void saveTransaction(TransactionEntity transactionEntity) {
		iTransactionDAO.saveTransaction(transactionEntity);
		
	}

}
