package com.zerochain.Transaction;

public interface ITransactionService {
	void saveTransaction(TransactionEntity transactionEntity);

}
