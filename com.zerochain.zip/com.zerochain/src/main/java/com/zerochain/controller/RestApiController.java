package com.zerochain.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.zerochain.Miner.IMinerService;
import com.zerochain.Miner.MinerEntity;
import com.zerochain.Transaction.ITransactionService;
import com.zerochain.Transaction.TransactionEntity;

@RestController
@RequestMapping("/v1")
public class RestApiController {
	private static Logger logger = Logger.getLogger(RestApiController.class);

	@Autowired 
	IMinerService iMinerService;
	
	@Autowired 
	ITransactionService iTransactionService;
	
	
	//--------- Post Registration--------
	
	@RequestMapping(value = "/registration", method = RequestMethod.POST)
	public ResponseEntity<?> postRegistration(@RequestBody MinerEntity minerEntity){
		System.out.println("here");
		logger.info("Adding Registration: "+ minerEntity);
		iMinerService.saveRegistration(minerEntity);
		
		return new ResponseEntity<String> ( "Success", HttpStatus.CREATED);
		
	}
	
	//---------- Post Transaction --------
	@RequestMapping(value ="/transaction", method = RequestMethod.POST)
	public ResponseEntity<?> postTransaction(@RequestBody TransactionEntity transactionEntity){
		System.out.println("In Transaction");
		logger.info("Adding Transaction: "+ transactionEntity);
		iTransactionService.saveTransaction(transactionEntity);
		
		return new ResponseEntity<String> ("Success" , HttpStatus.CREATED);
	}

}
