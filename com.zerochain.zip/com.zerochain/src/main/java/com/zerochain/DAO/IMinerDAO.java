package com.zerochain.DAO;

import com.zerochain.Miner.MinerEntity;

public interface IMinerDAO {
	void saveRegistration(MinerEntity minerEntity);

}
