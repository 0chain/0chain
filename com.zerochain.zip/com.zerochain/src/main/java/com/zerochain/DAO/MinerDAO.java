package com.zerochain.DAO;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zerochain.Miner.MinerEntity;

@Transactional
@Repository
public class MinerDAO implements IMinerDAO {
	
	@PersistenceContext 
	private EntityManager entityManager;
	
	@Override
	public void saveRegistration(MinerEntity minerEntity) {
		entityManager.persist(minerEntity);
	}

}
