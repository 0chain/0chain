package com.zerochain.Miner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zerochain.DAO.IMinerDAO;

@Service("minerService")
public class MinerSeviceImpl implements IMinerService {
	@Autowired 
	private IMinerDAO iMinerDAO;

	@Override
	public void saveRegistration(MinerEntity minerEntity) {
		// TODO Auto-generated method stub
		iMinerDAO.saveRegistration(minerEntity);
		
	}

}
