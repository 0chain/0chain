package com.zerochain.Miner;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import java.io.Serializable;

@Entity
@Table(name="clients")
public class MinerEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="id")
	private int id;

	@Column(name = "public_key")
	private String public_key;

	@Column(name = "hash_key")
	private String hash_key;

	@Column(name = "sign")
	private String sign;

	public MinerEntity(String public_key, String hash_key, String sign) {
		this.public_key = public_key;
		this.hash_key = hash_key;
		this.sign = sign;
	}

	public MinerEntity() {
	}

    public int getId() {
        return id;
    }

    public void setId(int id){
	    this.id = id;
    }

	public String getPublic_key() {
		return public_key;
	}
	public void setPublic_key(String public_key) {
		this.public_key = public_key;
	}

	public String getHash_key() {
		return hash_key;
	}
	public void setHash_key(String hash_key) {
		this.hash_key = hash_key;
	}

	public String getSign() {
		return sign;
	}
	public void setSign(String sign) {
		this.sign = sign;
	}

	@Override
	public String toString() {
		return "MinerEntity{" +
				", public_key='" + public_key + '\'' +
				", hash_key='" + hash_key + '\'' +
				", sign=" + sign +
				'}';
	}
}
