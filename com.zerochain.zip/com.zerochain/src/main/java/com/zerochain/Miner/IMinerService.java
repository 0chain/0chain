package com.zerochain.Miner;

public interface IMinerService {
	void saveRegistration(MinerEntity minerEntity);
}
