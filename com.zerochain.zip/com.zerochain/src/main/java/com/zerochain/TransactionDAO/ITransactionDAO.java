package com.zerochain.TransactionDAO;

import com.zerochain.Transaction.TransactionEntity;

public interface ITransactionDAO {
	void saveTransaction(TransactionEntity transactionEntity);

}
